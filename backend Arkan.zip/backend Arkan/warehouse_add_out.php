<?php
require_once "config.php";
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

// Ensure Item_Stock column exists (stores stock before this OUT)
$conn->query("ALTER TABLE warehouse_out ADD COLUMN IF NOT EXISTS Item_Stock DECIMAL(12,4) NULL AFTER qty");

$data = json_decode(file_get_contents("php://input"), true);
$item_id  = isset($data["item_id"]) ? intval($data["item_id"]) : 0;
$qty      = isset($data["qty"]) ? floatval($data["qty"]) : 0;
$reason   = isset($data["reason"]) ? trim($data["reason"]) : "usage";
$order_id = isset($data["order_id"]) ? (strlen($data["order_id"]) ? intval($data["order_id"]) : null) : null;
$note     = isset($data["note"]) ? trim($data["note"]) : null;
$issued_by= isset($data["issued_by"]) ? trim($data["issued_by"]) : null;
$supplier_id= isset($data["supplier_id"]) ? (strlen($data["supplier_id"]) ? trim($data["supplier_id"]) : null) : null;
// Optional custom issue date (YYYY-MM-DD) - save entered date
$issued_at = isset($data["issued_at"]) ? trim($data["issued_at"]) : null;
if ($issued_at !== null && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $issued_at)) {
  $issued_at = null; // invalid format -> ignore
}

// Today's date for ordering (always set)
$today_date = date('Y-m-d H:i:s');

if ($item_id <= 0 || $qty <= 0) {
  echo json_encode(["success"=>false, "message"=>"Invalid item or qty"]);
  exit;
}

// Read current stock before removing
$curStock = 0.0;
$q = $conn->prepare("SELECT quantity FROM warehouse_item WHERE item_id = ? LIMIT 1");
$q->bind_param("i", $item_id);
$q->execute();
$rr = $q->get_result()->fetch_assoc();
if ($rr) { $curStock = floatval($rr['quantity']) - $qty; }

if ($issued_at) {
  // Save entered date in issued_at, today's date in date
  $stmt = $conn->prepare("INSERT INTO warehouse_out (item_id, qty, Item_Stock, reason, order_id, supplier_id, note, issued_by, issued_at, date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
  $stmt->bind_param("iddsisssss", $item_id, $qty, $curStock, $reason, $order_id, $supplier_id, $note, $issued_by, $issued_at, $today_date);
} else {
  // No entered date, just save today's date in date column
  $stmt = $conn->prepare("INSERT INTO warehouse_out (item_id, qty, Item_Stock, reason, order_id, supplier_id, note, issued_by, date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
  $stmt->bind_param("iddsiisss", $item_id, $qty, $curStock, $reason, $order_id, $supplier_id, $note, $issued_by, $today_date);
}

if ($stmt->execute()) {
  // triggers will update warehouse_item.quantity
  echo json_encode(["success"=>true, "id"=>$conn->insert_id]);
} else {
  echo json_encode(["success"=>false, "message"=>"DB error: ".$stmt->error]);
}