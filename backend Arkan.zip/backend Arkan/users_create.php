<?php
// File: arkan-system/users_create.php
require_once __DIR__ . "/config.php";

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }

function bad($msg, $code=400) {
  http_response_code($code);
  echo json_encode(["success"=>false, "message"=>$msg]);
  exit;
}

$data = json_decode(file_get_contents("php://input"), true);
if (!$data) { $data = $_POST; }

$username = trim($data['username'] ?? '');
$password = (string)($data['password'] ?? '');
$role     = trim($data['role'] ?? '');
$email    = trim($data['email'] ?? '');
$phone    = trim($data['phone'] ?? '');

// Basic validation
if ($username === '' || $password === '' || $role === '') bad("username, password and role are required");

// Allowed roles (based on your DB)
$allowed = ['admin','finance','account manager','designer','designer manager'];
if (!in_array(strtolower($role), $allowed, true)) {
  bad("Invalid role. Allowed: ".implode(", ", $allowed));
}

// Enforce unique username
$chk = $conn->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
$chk->bind_param("s", $username);
$chk->execute();
if ($chk->get_result()->fetch_assoc()) bad("Username already exists");

// NOTE: keep plain to match existing login; switch to hash later:
// $password = password_hash($password, PASSWORD_DEFAULT);

try {
  $ins = $conn->prepare("INSERT INTO users (username, password, role, email, phone) VALUES (?, ?, ?, ?, ?)");
  $ins->bind_param("sssss", $username, $password, $role, $email, $phone);
  $ins->execute();

  echo json_encode([
    "success" => true,
    "message" => "User created",
    "user_id" => $ins->insert_id
  ]);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(["success"=>false, "message"=>"Insert failed", "error"=>$e->getMessage()]);
}
