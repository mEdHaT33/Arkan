<?php
require_once "config.php";

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  http_response_code(200);
  exit;
}

// Debug (optional while testing)
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

$input = json_decode(file_get_contents("php://input"), true);

$item_code      = trim($input["item_code"] ?? "");
$item_name      = trim($input["item_name"] ?? "");
$description    = trim($input["description"] ?? "");
$category       = trim($input["category"] ?? "");
$qty            = isset($input["qty"]) ? floatval($input["qty"]) : 0;
$unit           = trim($input["unit"] ?? "pcs");
$purchase_price = isset($input["purchase_price"]) ? floatval($input["purchase_price"]) : 0;
$selling_price  = isset($input["selling_price"]) ? floatval($input["selling_price"]) : 0;
$supplier_id    = isset($input["supplier_id"]) && $input["supplier_id"] !== "" ? intval($input["supplier_id"]) : null;
$reorder_level  = isset($input["reorder_level"]) ? floatval($input["reorder_level"]) : 0;
$location       = trim($input["location"] ?? "");

if ($item_name === "") {
  echo json_encode(["success" => false, "message" => "Item name is required"]);
  exit;
}

$stmt = $conn->prepare("
  INSERT INTO warehouse_item
  (item_code, item_name, description, category, quantity, unit, purchase_price, selling_price, supplier_id, reorder_level, location, status, created_at, updated_at)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', NOW(), NOW())
");

if (!$stmt) {
  echo json_encode(["success" => false, "message" => "Prepare failed: ".$conn->error]);
  exit;
}

/*
  Types:
  s item_code
  s item_name
  s description
  s category
  d quantity
  s unit
  d purchase_price
  d selling_price
  i supplier_id (nullable -> use null + bind as NULL via dynamic binding)
  d reorder_level
  s location
*/
if ($supplier_id === null) {
  // bind null for supplier_id safely: use NULL in SQL via set to null and bind as string/int still okay in MySQLi
  $stmt->bind_param(
    "ssssdsddids",
    $item_code, $item_name, $description, $category, $qty, $unit,
    $purchase_price, $selling_price, $supplier_id, $reorder_level, $location
  );
} else {
  $stmt->bind_param(
    "ssssdsddids",
    $item_code, $item_name, $description, $category, $qty, $unit,
    $purchase_price, $selling_price, $supplier_id, $reorder_level, $location
  );
}

if ($stmt->execute()) {
  echo json_encode(["success" => true, "id" => $conn->insert_id]);
} else {
  echo json_encode(["success" => false, "message" => "DB error: ".$stmt->error]);
}
