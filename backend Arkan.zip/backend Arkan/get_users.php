<?php
session_start();
header("Content-Type: application/json");

// Check if user is logged in and is admin
if (!isset($_SESSION["loggedin"]) || $_SESSION["role"] !== "admin") {
    http_response_code(403);
    echo json_encode(["error" => "Access denied"]);
    exit;
}

include("config.php");

// Fetch all users
$result = $conn->query("SELECT id, username, role, email, phone FROM users ORDER BY id DESC");

$users = [];
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}

echo json_encode(["status" => "success", "users" => $users]);
?>
