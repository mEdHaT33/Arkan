<?php
require_once "config.php";
header("Content-Type: application/json");

// Read JSON body
$data = json_decode(file_get_contents("php://input"), true);
$order_id = isset($data["order_id"]) ? intval($data["order_id"]) : null;
$action   = $data["action"] ?? null;          // e.g., upload_brief, confirm_no_3d, assign_designer, upload_prova, approve_prova, etc.
$role     = $data["role"]   ?? null;          // e.g., "account manager", "designer manager", "designer team", "finance"
$user     = $data["user"]   ?? $role;         // optional: who exactly (username). Falls back to role if not provided.

if (!$order_id || !$action || !$role) {
    echo json_encode(["success" => false, "message" => "Missing parameters"]);
    exit;
}

/**
 * Canonical statuses (new workflow):
 * - pending
 * - brief uploaded
 * - waiting for 3d
 * - design phase
 * - prova uploaded
 * - approved
 * - production files uploaded
 * - images uploaded
 * - invoice uploaded
 */

// Map actions to statuses (pure mapping; transition checks optional below)
$statusMap = [
    // Account Manager
    "upload_brief"        => "brief uploaded",
    "confirm_no_3d"       => "waiting for 3d",
    "confirm_has_3d"      => "design phase",
    "upload_images"       => "images uploaded",
    "upload_quotation"    => "quotation uploaded", // keep if you still want to show quotes separately

    // Designer Manager
    "assign_designer"     => "design phase",
    "approve_prova"       => "approved",

    // Designer Team
    "upload_d3"           => "design phase",               // when 3D is provided, we are actively in design phase
    "upload_prova"        => "prova uploaded",
    "upload_production"   => "production files uploaded",

    // Finance
    "upload_invoice"      => "invoice uploaded"
];

if (!isset($statusMap[$action])) {
    echo json_encode(["success" => false, "message" => "Invalid action"]);
    exit;
}

$newStatus = $statusMap[$action];

// (Optional) Fetch current status to validate transitions or include in tracking/response
$cur = $conn->prepare("SELECT status FROM orders WHERE order_id = ?");
$cur->bind_param("i", $order_id);
$cur->execute();
$curRes = $cur->get_result();
if ($curRes->num_rows === 0) {
    echo json_encode(["success" => false, "message" => "Order not found"]);
    exit;
}
$row = $curRes->fetch_assoc();
$oldStatus = $row["status"] ?? null;

// (Optional) Simple transition guardrails — customize as you like
$allowedTransitions = [
    // from => allowed next statuses
    "pending" => ["brief uploaded"],
    "brief uploaded" => ["waiting for 3d", "design phase", "quotation uploaded"],
    "waiting for 3d" => ["design phase", "prova uploaded"], // if designer uploads directly
    "design phase" => ["prova uploaded", "production files uploaded"], // if skipping prova (rare)
    "prova uploaded" => ["approved"],
    "approved" => ["production files uploaded", "images uploaded"],
    "production files uploaded" => ["images uploaded"],
    "images uploaded" => ["invoice uploaded"],
    "invoice uploaded" => [],

    // Fallback for unknown old status (let it move to newStatus)
    "" => [$newStatus],
    null => [$newStatus],
];

// If oldStatus not listed, allow the change (or tighten if needed)
if (isset($allowedTransitions[$oldStatus]) && !in_array($newStatus, $allowedTransitions[$oldStatus], true)) {
    // You can choose to block or allow; here we allow but note it.
    // To block, uncomment the next two lines:
    // echo json_encode(["success" => false, "message" => "Illegal transition: $oldStatus → $newStatus"]);
    // exit;
}

// Update order status
$upd = $conn->prepare("UPDATE orders SET status = ?, updated_at = NOW() WHERE order_id = ?");
$upd->bind_param("si", $newStatus, $order_id);

if ($upd->execute()) {
    // Tracking: who changed + old/new
    $changedBy = $user ?: $role;
    $track = $conn->prepare("
        INSERT INTO order_tracking (order_id, status, changed_by, changed_at, notes)
        VALUES (?, ?, ?, NOW(), ?)
    ");
    $note = "transition: " . ($oldStatus ?: "none") . " → " . $newStatus . " via action: " . $action;
    $track->bind_param("isss", $order_id, $newStatus, $changedBy, $note);
    $track->execute();

    echo json_encode([
        "success"       => true,
        "order_id"      => $order_id,
        "old_status"    => $oldStatus,
        "status"        => $newStatus,
        "action"        => $action,
        "changed_by"    => $changedBy
    ]);
} else {
    echo json_encode(["success" => false, "message" => "Database update failed"]);
}
