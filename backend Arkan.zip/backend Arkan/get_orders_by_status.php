<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

require_once "config.php";

$status = $_GET['status'] ?? null;

$sql = "SELECT * FROM orders";

if (!empty($status) && $status !== "all") {
    $sql .= " WHERE status = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $status);
} else {
    $stmt = $conn->prepare($sql);
}

if ($stmt->execute()) {
    $result = $stmt->get_result();
    $orders = [];
    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }
    echo json_encode(["success" => true, "orders" => $orders]);
} else {
    echo json_encode(["success" => false, "message" => "Database error"]);
}
?>
