<?php
require_once "config.php";
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$item_id = isset($_GET["item_id"]) ? intval($_GET["item_id"]) : 0;
$from    = isset($_GET["from"]) ? $_GET["from"] : null;
$to      = isset($_GET["to"]) ? $_GET["to"] : null;
$limit   = isset($_GET["limit"]) ? intval($_GET["limit"]) : 100;

$sql = "SELECT w.id, w.item_id, i.item_code, i.item_name, w.qty, w.unit_cost, w.total_cost,w.Item_Stock,
               w.supplier_id, w.po_number, w.note, w.received_by, w.received_at, w.date
        FROM warehouse_in w
        JOIN warehouse_item i ON i.item_id = w.item_id
        WHERE 1=1";
$params = []; $types = "";

if ($item_id > 0) { $sql .= " AND w.item_id = ?"; $types .= "i"; $params[] = $item_id; }
if ($from) { $sql .= " AND DATE(w.received_at) >= ?"; $types .= "s"; $params[] = $from; }
if ($to)   { $sql .= " AND DATE(w.received_at) <= ?"; $types .= "s"; $params[] = $to; }

$sql .= " ORDER BY w.date DESC LIMIT ?";
$types .= "i"; $params[] = $limit;

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();

$rows = [];
while ($row = $res->fetch_assoc()) $rows[] = $row;

echo json_encode(["success"=>true, "items"=>$rows]);
