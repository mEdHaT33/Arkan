<?php
require_once "config.php";
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }

try {
  $data = json_decode(file_get_contents("php://input"), true);
  if (!is_array($data)) {
    throw new Exception("Invalid JSON body");
  }

  $txn_date    = $data["txn_date"]    ?? date("Y-m-d");
  $category_id = isset($data["category_id"]) ? (int)$data["category_id"] : null;
  $account     = $data["account"]     ?? null;     // "bank" | "cash"
  $direction   = $data["direction"]   ?? null;     // "in" | "out"
  $amount      = isset($data["amount"]) ? (float)$data["amount"] : null;
  $note        = $data["note"]        ?? "";
  $user        = $data["user"]        ?? "";

  // Optional: link transaction to a party and update its balance
  $party_type = isset($data['party_type']) ? strtolower(trim($data['party_type'])) : '';
  $party_id   = isset($data['party_id']) ? (int)$data['party_id'] : 0;

  if (!$category_id || !$account || !$direction || $amount === null) {
    throw new Exception("Missing parameters (need category_id, account, direction, amount)");
  }
  if (!in_array($account, ["bank","cash"], true)) {
    throw new Exception("Invalid account: $account (must be bank|cash)");
  }
  if (!in_array($direction, ["in","out"], true)) {
    throw new Exception("Invalid direction: $direction (must be in|out)");
  }
  if ($amount < 0) {
    throw new Exception("Amount must be >= 0");
  }

  // Resolve account_id
  $stmt = $conn->prepare("SELECT id FROM finance_account WHERE type=? LIMIT 1");
  if (!$stmt) throw new Exception("Prepare failed (account lookup): ".$conn->error);
  $stmt->bind_param("s", $account);
  $stmt->execute();
  $res = $stmt->get_result();
  if ($res->num_rows === 0) {
    throw new Exception("Account not found. Did you run the finance SQL to seed Bank/Cash?");
  }
  $account_id = (int)$res->fetch_assoc()["id"];
  $stmt->close();

  // Insert transaction (DB trigger should fill *_balance_after)
  $stmt = $conn->prepare(
    "INSERT INTO finance_txn (txn_date, category_id, account_id, direction, amount, note, created_by)
     VALUES (?,?,?,?,?,?,?)"
  );
  if (!$stmt) throw new Exception("Prepare failed (insert txn): ".$conn->error);

  $dir = $direction;            // bind needs simple vars
  $amt = (float)$amount;
  if (!$stmt->bind_param("siisdss", $txn_date, $category_id, $account_id, $dir, $amt, $note, $user)) {
    throw new Exception("Bind failed: ".$stmt->error);
  }

  if (!$stmt->execute()) {
    throw new Exception("DB insert failed: ".$stmt->error);
  }

  $newId = (int)$conn->insert_id;
  $stmt->close();

  // If a party is selected, update the party balance according to direction and party type
  $updated_party_balance = null;
  if ($party_id > 0 && ($party_type === 'client' || $party_type === 'vendor')) {
    // client: IN reduces debt (-amount), OUT increases debt (+amount)
    // vendor: OUT reduces payable (-amount), IN increases payable (+amount)
    $delta = 0.0;
    if ($party_type === 'client') {
      $delta = ($direction === 'in') ? -$amount : +$amount;
    } else if ($party_type === 'vendor') {
      $delta = ($direction === 'out') ? -$amount : +$amount;
    }

    // Try unified table first
    if ($upd = $conn->prepare("UPDATE clients_vendors SET balance = balance + ? WHERE id = ?")) {
      $upd->bind_param("di", $delta, $party_id);
      $upd->execute();
      $upd->close();
    }
    // Read updated balance if available
    if ($selp = $conn->prepare("SELECT balance FROM clients_vendors WHERE id = ? LIMIT 1")) {
      $selp->bind_param("i", $party_id);
      $selp->execute();
      $rp = $selp->get_result();
      if ($rp && $rowp = $rp->fetch_assoc()) {
        $updated_party_balance = (float)$rowp['balance'];
      }
      $selp->close();
    }
  }

  // Fetch the running balances for THIS row
  $sel = $conn->prepare("
    SELECT cash_balance_after, bank_balance_after
    FROM finance_txn
    WHERE id = ?
    LIMIT 1
  ");
  if (!$sel) throw new Exception("Prepare failed (select balances): ".$conn->error);
  $sel->bind_param("i", $newId);
  $sel->execute();
  $r = $sel->get_result();
  $row = $r ? $r->fetch_assoc() : null;
  $sel->close();

  $cash_after = isset($row['cash_balance_after']) ? (float)$row['cash_balance_after'] : null;
  $bank_after = isset($row['bank_balance_after']) ? (float)$row['bank_balance_after'] : null;

  // Fallback: if trigger didn’t populate yet, use latest row’s balances
  if ($cash_after === null || $bank_after === null) {
    $fallback = $conn->query("
      SELECT cash_balance_after, bank_balance_after
      FROM finance_txn
      ORDER BY txn_date DESC, id DESC
      LIMIT 1
    ");
    if ($fallback && $fallback->num_rows) {
      $f = $fallback->fetch_assoc();
      if ($cash_after === null) $cash_after = (float)$f['cash_balance_after'];
      if ($bank_after === null) $bank_after = (float)$f['bank_balance_after'];
    }
  }

  $resp = [
    "success" => true,
    "id" => $newId,
    "cash_balance_after" => $cash_after,
    "bank_balance_after" => $bank_after
  ];
  if ($party_id > 0 && $updated_party_balance !== null) {
    $resp['party'] = [ 'id' => $party_id, 'type' => $party_type, 'balance' => $updated_party_balance ];
  }
  echo json_encode($resp);

} catch (Exception $e) {
  http_response_code(400);
  echo json_encode([
    "success"=>false,
    "message"=>"finance_add_transaction error",
    "error"=>$e->getMessage()
  ]);
}
