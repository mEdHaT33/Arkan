<?php
require_once "config.php";
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$res = $conn->query("SELECT username, email, phone FROM users WHERE LOWER(role) = 'designer'");

$users = [];
while ($row = $res->fetch_assoc()) {
  $users[] = $row;
}

echo json_encode(["success" => true, "users" => $users]);
?>
