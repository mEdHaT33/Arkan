<?php
require_once "config.php";
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$sql = "SELECT id, name FROM clients WHERE type = 'Supplier'";
$result = $conn->query($sql);

$vendors = [];
while ($row = $result->fetch_assoc()) {
    $vendors[] = $row;
}

echo json_encode(["success" => true, "vendors" => $vendors]);
?>
