<?php
require_once "config.php";
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);
$order_id = $data['order_id'] ?? null;
$approved_by = $data['approved_by'] ?? "system";

if (!$order_id) {
    echo json_encode(["success" => false, "message" => "Missing order_id"]);
    exit;
}

$new_status = "approved";

// Update status
$stmt = $conn->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
$stmt->bind_param("si", $new_status, $order_id);
$stmt->execute();

// Insert tracking log
$comment = "Prova approved manually";
$track = $conn->prepare("INSERT INTO order_tracking (order_id, status, assigned_to, comments, timestamp) VALUES (?, ?, ?, ?, NOW())");
$track->bind_param("isss", $order_id, $new_status, $approved_by, $comment);
$track->execute();

// Respond
echo json_encode([
    "success" => true,
    "message" => "Prova approved",
]);
?>
