<?php
// File: arkan-system/users_list.php
require_once __DIR__ . "/config.php";

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }

try {
  $sql = "SELECT id, username, role, email, phone FROM users ORDER BY id DESC";
  $res = $conn->query($sql);
  $rows = [];
  while ($r = $res->fetch_assoc()) { $rows[] = $r; }

  echo json_encode([
    "success" => true,
    "users" => $rows
  ]);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(["success" => false, "message" => "Server error", "error" => $e->getMessage()]);
}
