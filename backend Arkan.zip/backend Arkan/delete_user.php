<?php
session_start();
header("Content-Type: application/json");

// Only admin can delete
if (!isset($_SESSION["loggedin"]) || $_SESSION["role"] !== "admin") {
    http_response_code(403);
    echo json_encode(["error" => "Access denied"]);
    exit;
}

include("config.php");

// Read user ID from query param (e.g., ?id=4)
if (!isset($_GET["id"])) {
    http_response_code(400);
    echo json_encode(["error" => "User ID required"]);
    exit;
}

$id = intval($_GET["id"]);

// Prevent deleting self
if ($id == $_SESSION["user_id"]) {
    http_response_code(403);
    echo json_encode(["error" => "Cannot delete your own account"]);
    exit;
}

$conn->query("DELETE FROM users WHERE id = $id");

if ($conn->affected_rows > 0) {
    echo json_encode(["status" => "success", "message" => "User deleted"]);
} else {
    http_response_code(404);
    echo json_encode(["error" => "User not found or already deleted"]);
}
?>
