<?php
require_once "config.php";
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$sql = "SELECT item_id, item_code, item_name, description, category,
               quantity, unit, purchase_price, selling_price,
               supplier_id, reorder_level, location, status,
               created_at, updated_at
        FROM warehouse_item
        ORDER BY item_name ASC";

$res = $conn->query($sql);
$items = [];
if ($res) {
  while ($row = $res->fetch_assoc()) $items[] = $row;
}

echo json_encode(["success" => true, "items" => $items]);
