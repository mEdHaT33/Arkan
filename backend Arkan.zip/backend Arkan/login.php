<?php
// CORS allow-list
$allowed_origins = [
  'http://localhost:3000',
  'http://localhost:5173',
  'http://127.0.0.1:5173',
  'https://arkanaltafawuq.com',
  'https://www.arkanaltafawuq.com',
];
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin && in_array($origin, $allowed_origins, true)) {
    header("Access-Control-Allow-Origin: $origin");
    header("Access-Control-Allow-Credentials: true");
}
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }

// IMPORTANT: set session cookie params BEFORE session_start()
if (PHP_VERSION_ID >= 70300) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '.arkanaltafawuq.com', // works for apex & www
        'secure'   => true,
        'httponly' => true,
        'samesite' => 'None',                // allow cross-site
    ]);
} else {
    ini_set('session.cookie_secure', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'None');
    ini_set('session.cookie_domain', '.arkanaltafawuq.com');
}
session_start();

require_once "config.php";

$data = json_decode(file_get_contents("php://input"), true);
$username = $data["username"] ?? '';
$password = $data["password"] ?? '';

$stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows === 1) {
    $user = $result->fetch_assoc();
    $_SESSION["loggedin"] = true;
    $_SESSION["username"] = $user["username"];
    $_SESSION["role"]     = $user["role"];

    echo json_encode([
        "success"  => true,
        "username" => $user["username"],
        "role"     => $user["role"]
    ]);
} else {
    echo json_encode(["success" => false, "message" => "Invalid credentials"]);
}
