<?php
// File: arkan-system/excel_import.php
require_once __DIR__ . "/config.php";
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }

function bad($msg, $code = 400) {
  http_response_code($code);
  echo json_encode(["success" => false, "message" => $msg]);
  exit;
}

function success($msg, $data = []) {
  echo json_encode(["success" => true, "message" => $msg, "data" => $data]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Check if file was uploaded
  if (!isset($_FILES['excel_file']) || $_FILES['excel_file']['error'] !== UPLOAD_ERR_OK) {
    bad("No file uploaded or upload error");
  }

  $file = $_FILES['excel_file'];
  $import_type = $_POST['import_type'] ?? '';
  $skip_duplicates = isset($_POST['skip_duplicates']) ? true : false;

  // Validate file type - CSV only
  $allowed_extensions = ['csv'];
  $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
  
  if (!in_array($file_extension, $allowed_extensions)) {
    bad("Invalid file type. Please upload CSV files only (.csv)");
  }

  // Validate import type
  $valid_types = ['warehouse_items', 'clients_vendors', 'users', 'financial_transactions', 'receipts'];
  if (!in_array($import_type, $valid_types)) {
    bad("Invalid import type. Valid types: " . implode(', ', $valid_types));
  }

  // Create uploads directory if it doesn't exist
  $upload_dir = __DIR__ . '/uploads/';
  if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
  }

  // Move uploaded file
  $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
  $filename = 'import_' . time() . '.' . $file_extension;
  $file_path = $upload_dir . $filename;

  if (!move_uploaded_file($file['tmp_name'], $file_path)) {
    bad("Failed to save uploaded file");
  }

  try {
    // Parse Excel file
    $data = parseExcelFile($file_path, $import_type);
    
    // Import data to database
    $result = importDataToDatabase($data, $import_type, $skip_duplicates);
    
    // Clean up uploaded file
    unlink($file_path);
    
    success("Import completed successfully", $result);
    
  } catch (Exception $e) {
    // Clean up uploaded file on error
    if (file_exists($file_path)) {
      unlink($file_path);
    }
    bad("Import failed: " . $e->getMessage());
  }
}

function parseExcelFile($file_path, $import_type) {
  // Simple CSV parsing - CSV files only with BOM handling
  
  $handle = fopen($file_path, 'r');
  if (!$handle) {
    throw new Exception("Could not open file");
  }

  $data = [];
  $headers = [];
  $row_index = 0;

  while (($row = fgetcsv($handle)) !== FALSE) {
    if ($row_index === 0) {
      // First row contains headers
      $headers = array_map('trim', $row);
      
      // Remove BOM (Byte Order Mark) from first header if present
      if (!empty($headers[0])) {
        $headers[0] = preg_replace('/^\xEF\xBB\xBF/', '', $headers[0]); // UTF-8 BOM
        $headers[0] = preg_replace('/^\xFE\xFF/', '', $headers[0]); // UTF-16 BE BOM
        $headers[0] = preg_replace('/^\xFF\xFE/', '', $headers[0]); // UTF-16 LE BOM
        $headers[0] = trim($headers[0]);
      }
      
      // Debug: Log headers found
      error_log("CSV Import - Headers found: " . implode(', ', $headers));
      
      // Check for required headers based on import type
      if ($import_type === 'warehouse_items') {
        $required_headers = ['item_code', 'item_name'];
        $missing_headers = array_diff($required_headers, $headers);
        if (!empty($missing_headers)) {
          throw new Exception("Missing required headers: " . implode(', ', $missing_headers) . ". Found headers: " . implode(', ', $headers));
        }
      }
    } else {
      // Data rows
      $row_data = [];
      for ($i = 0; $i < count($headers); $i++) {
        $value = isset($row[$i]) ? trim($row[$i]) : '';
        $row_data[$headers[$i]] = $value;
      }
      
      // Skip completely empty rows
      $has_data = false;
      foreach ($row_data as $value) {
        if (!empty($value)) {
          $has_data = true;
          break;
        }
      }
      
      if ($has_data) {
        $data[] = $row_data;
      }
    }
    $row_index++;
  }
  fclose($handle);

  // Debug: Log data found
  error_log("CSV Import - Found " . count($data) . " data rows");
  if (!empty($data)) {
    error_log("CSV Import - First row sample: " . json_encode($data[0]));
  }

  return $data;
}

function importDataToDatabase($data, $import_type, $skip_duplicates) {
  global $conn;
  
  $conn->begin_transaction();
  $imported = 0;
  $skipped = 0;
  $errors = [];

  try {
    switch ($import_type) {
      case 'warehouse_items':
        $result = importWarehouseItems($data, $skip_duplicates);
        break;
      case 'clients_vendors':
        $result = importClientsVendors($data, $skip_duplicates);
        break;
      case 'users':
        $result = importUsers($data, $skip_duplicates);
        break;
      case 'financial_transactions':
        $result = importFinancialTransactions($data, $skip_duplicates);
        break;
      case 'receipts':
        $result = importReceipts($data, $skip_duplicates);
        break;
      default:
        throw new Exception("Unknown import type");
    }

    $conn->commit();
    return $result;
    
  } catch (Exception $e) {
    $conn->rollback();
    throw $e;
  }
}

function importWarehouseItems($data, $skip_duplicates) {
  global $conn;
  
  $imported = 0;
  $skipped = 0;
  $errors = [];

  foreach ($data as $row) {
    try {
      // Required fields validation
      if (empty($row['item_code']) || empty($row['item_name'])) {
        $errors[] = "Row missing item_code or item_name";
        continue;
      }

      // Check for duplicates
      if ($skip_duplicates) {
        $check = $conn->prepare("SELECT item_id FROM warehouse_item WHERE item_code = ?");
        $check->bind_param("s", $row['item_code']);
        $check->execute();
        if ($check->get_result()->fetch_assoc()) {
          $skipped++;
          continue;
        }
      }

      // Insert warehouse item
      $stmt = $conn->prepare("
        INSERT INTO warehouse_item (
          item_code, item_name, description, category, quantity, unit,
          purchase_price, selling_price, supplier_id, reorder_level, location, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ");

      $item_code = $row['item_code'];
      $item_name = $row['item_name'];
      $description = $row['description'] ?? '';
      $category = $row['category'] ?? '';
      $quantity = floatval($row['quantity'] ?? 0);
      $unit = $row['unit'] ?? 'pcs';
      $purchase_price = floatval($row['purchase_price'] ?? 0);
      $selling_price = floatval($row['selling_price'] ?? 0);
      $supplier_id = !empty($row['supplier_id']) ? intval($row['supplier_id']) : null;
      $reorder_level = floatval($row['reorder_level'] ?? 0);
      $location = $row['location'] ?? '';
      $status = $row['status'] ?? 'active';

      $stmt->bind_param("ssssdsddidss", 
        $item_code, $item_name, $description, $category, $quantity, $unit,
        $purchase_price, $selling_price, $supplier_id, $reorder_level, $location, $status
      );

      if ($stmt->execute()) {
        $imported++;
      } else {
        $errors[] = "Failed to insert item: " . $item_code;
      }

    } catch (Exception $e) {
      $errors[] = "Error processing row: " . $e->getMessage();
    }
  }

  return ['imported' => $imported, 'skipped' => $skipped, 'errors' => $errors];
}

function importClientsVendors($data, $skip_duplicates) {
  global $conn;
  
  $imported = 0;
  $skipped = 0;
  $errors = [];

  foreach ($data as $row) {
    try {
      // Required fields validation
      if (empty($row['name']) || empty($row['type'])) {
        $errors[] = "Row missing name or type";
        continue;
      }

      $type = strtolower($row['type']);
      if (!in_array($type, ['client', 'vendor'])) {
        $errors[] = "Invalid type: " . $row['type'];
        continue;
      }

      // Check for duplicates
      if ($skip_duplicates) {
        $check = $conn->prepare("SELECT id FROM clients_vendors WHERE name = ? AND type = ?");
        $check->bind_param("ss", $row['name'], $type);
        $check->execute();
        if ($check->get_result()->fetch_assoc()) {
          $skipped++;
          continue;
        }
      }

      // Insert client/vendor
      $stmt = $conn->prepare("
        INSERT INTO clients_vendors (name, type, balance, email, phone, address)
        VALUES (?, ?, ?, ?, ?, ?)
      ");

      $name = $row['name'];
      $balance = floatval($row['balance'] ?? 0);
      $email = $row['email'] ?? '';
      $phone = $row['phone'] ?? '';
      $address = $row['address'] ?? '';

      $stmt->bind_param("ssdsss", $name, $type, $balance, $email, $phone, $address);

      if ($stmt->execute()) {
        $imported++;
      } else {
        $errors[] = "Failed to insert: " . $name;
      }

    } catch (Exception $e) {
      $errors[] = "Error processing row: " . $e->getMessage();
    }
  }

  return ['imported' => $imported, 'skipped' => $skipped, 'errors' => $errors];
}

function importUsers($data, $skip_duplicates) {
  global $conn;
  
  $imported = 0;
  $skipped = 0;
  $errors = [];

  foreach ($data as $row) {
    try {
      // Required fields validation
      if (empty($row['username']) || empty($row['password']) || empty($row['role'])) {
        $errors[] = "Row missing username, password, or role";
        continue;
      }

      // Check for duplicates
      if ($skip_duplicates) {
        $check = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $check->bind_param("s", $row['username']);
        $check->execute();
        if ($check->get_result()->fetch_assoc()) {
          $skipped++;
          continue;
        }
      }

      // Insert user
      $stmt = $conn->prepare("
        INSERT INTO users (username, password, role, email, phone)
        VALUES (?, ?, ?, ?, ?)
      ");

      $username = $row['username'];
      $password = $row['password']; // Keep plain for now to match existing system
      $role = $row['role'];
      $email = $row['email'] ?? '';
      $phone = $row['phone'] ?? '';

      $stmt->bind_param("sssss", $username, $password, $role, $email, $phone);

      if ($stmt->execute()) {
        $imported++;
      } else {
        $errors[] = "Failed to insert user: " . $username;
      }

    } catch (Exception $e) {
      $errors[] = "Error processing row: " . $e->getMessage();
    }
  }

  return ['imported' => $imported, 'skipped' => $skipped, 'errors' => $errors];
}

function importFinancialTransactions($data, $skip_duplicates) {
  global $conn;
  
  $imported = 0;
  $skipped = 0;
  $errors = [];

  foreach ($data as $row) {
    try {
      // Required fields validation
      if (empty($row['txn_date']) || empty($row['direction']) || empty($row['amount'])) {
        $errors[] = "Row missing txn_date, direction, or amount";
        continue;
      }

      $direction = strtolower($row['direction']);
      if (!in_array($direction, ['in', 'out'])) {
        $errors[] = "Invalid direction: " . $row['direction'];
        continue;
      }

      // Get or create category
      $category_name = $row['category'] ?? 'General';
      $category_kind = $row['category_kind'] ?? ($direction === 'in' ? 'income' : 'expense');
      
      $cat_stmt = $conn->prepare("SELECT id FROM finance_category WHERE name = ? AND kind = ?");
      $cat_stmt->bind_param("ss", $category_name, $category_kind);
      $cat_stmt->execute();
      $cat_result = $cat_stmt->get_result()->fetch_assoc();
      
      if ($cat_result) {
        $category_id = $cat_result['id'];
      } else {
        $cat_ins = $conn->prepare("INSERT INTO finance_category (name, kind) VALUES (?, ?)");
        $cat_ins->bind_param("ss", $category_name, $category_kind);
        $cat_ins->execute();
        $category_id = $cat_ins->insert_id;
      }

      // Get or create account
      $account_type = $row['account_type'] ?? 'bank';
      $acc_stmt = $conn->prepare("SELECT id FROM finance_account WHERE type = ?");
      $acc_stmt->bind_param("s", $account_type);
      $acc_stmt->execute();
      $acc_result = $acc_stmt->get_result()->fetch_assoc();
      
      if ($acc_result) {
        $account_id = $acc_result['id'];
      } else {
        $acc_name = ucfirst($account_type);
        $acc_ins = $conn->prepare("INSERT INTO finance_account (name, type) VALUES (?, ?)");
        $acc_ins->bind_param("ss", $acc_name, $account_type);
        $acc_ins->execute();
        $account_id = $acc_ins->insert_id;
      }

      // Insert transaction
      $stmt = $conn->prepare("
        INSERT INTO finance_txn (txn_date, category_id, account_id, direction, amount, note, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      ");

      $txn_date = $row['txn_date'];
      $amount = floatval($row['amount']);
      $note = $row['note'] ?? '';
      $created_by = $row['created_by'] ?? 'excel_import';

      $stmt->bind_param("siissss", $txn_date, $category_id, $account_id, $direction, $amount, $note, $created_by);

      if ($stmt->execute()) {
        $imported++;
      } else {
        $errors[] = "Failed to insert transaction";
      }

    } catch (Exception $e) {
      $errors[] = "Error processing row: " . $e->getMessage();
    }
  }

  return ['imported' => $imported, 'skipped' => $skipped, 'errors' => $errors];
}

function importReceipts($data, $skip_duplicates) {
  global $conn;
  
  $imported = 0;
  $skipped = 0;
  $errors = [];

  foreach ($data as $row) {
    try {
      // Required fields validation
      if (empty($row['direction']) || empty($row['party_type']) || empty($row['party_id']) || empty($row['amount'])) {
        $errors[] = "Row missing required fields";
        continue;
      }

      $direction = strtolower($row['direction']);
      $party_type = strtolower($row['party_type']);
      
      if (!in_array($direction, ['in', 'out']) || !in_array($party_type, ['client', 'vendor'])) {
        $errors[] = "Invalid direction or party_type";
        continue;
      }

      // Insert receipt
      $stmt = $conn->prepare("
        INSERT INTO party_receipts (direction, party_type, party_id, amount, method, reference, note, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ");

      $party_id = intval($row['party_id']);
      $amount = floatval($row['amount']);
      $method = $row['method'] ?? '';
      $reference = $row['reference'] ?? '';
      $note = $row['note'] ?? '';
      $created_by = $row['created_by'] ?? 'excel_import';

      $stmt->bind_param("ssidssss", $direction, $party_type, $party_id, $amount, $method, $reference, $note, $created_by);

      if ($stmt->execute()) {
        $imported++;
      } else {
        $errors[] = "Failed to insert receipt";
      }

    } catch (Exception $e) {
      $errors[] = "Error processing row: " . $e->getMessage();
    }
  }

  return ['imported' => $imported, 'skipped' => $skipped, 'errors' => $errors];
}

// GET method to show import templates
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  $templates = [
    'warehouse_items' => [
      'headers' => ['item_code', 'item_name', 'description', 'category', 'quantity', 'unit', 'purchase_price', 'selling_price', 'supplier_id', 'reorder_level', 'location', 'status'],
      'description' => 'Import warehouse items/inventory'
    ],
    'clients_vendors' => [
      'headers' => ['name', 'type', 'balance', 'email', 'phone', 'address'],
      'description' => 'Import clients and vendors (type: client or vendor)'
    ],
    'users' => [
      'headers' => ['username', 'password', 'role', 'email', 'phone'],
      'description' => 'Import system users'
    ],
    'financial_transactions' => [
      'headers' => ['txn_date', 'direction', 'amount', 'category', 'category_kind', 'account_type', 'note', 'created_by'],
      'description' => 'Import financial transactions (direction: in or out)'
    ],
    'receipts' => [
      'headers' => ['direction', 'party_type', 'party_id', 'amount', 'method', 'reference', 'note', 'created_by'],
      'description' => 'Import receipts (direction: in or out, party_type: client or vendor)'
    ]
  ];

  echo json_encode(["success" => true, "templates" => $templates]);
}
?>
