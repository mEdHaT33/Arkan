<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once "config.php";

$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

$id = $data['id'] ?? null;

if (!$id) {
  echo json_encode(["success" => false, "message" => "Missing user id."]);
  exit;
}

try {
  $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
  $stmt->bind_param("i", $id);
  if (!$stmt->execute()) {
    echo json_encode(["success" => false, "message" => "Database error: ".$stmt->error]); exit;
  }
  echo json_encode(["success" => true]);
} catch (Throwable $e) {
  echo json_encode(["success" => false, "message" => "Server error: ".$e->getMessage()]);
}
