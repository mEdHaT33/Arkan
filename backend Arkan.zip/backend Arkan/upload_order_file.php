<?php
require_once "config.php";
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Inputs
$order_id = $_POST['order_id'] ?? null;
$field = $_POST['field'] ?? null;
$file = $_FILES['file'] ?? null;
$assigned_to = $_POST['assigned_to'] ?? "system"; // future use

if (!$order_id || !$field || !$file) {
    echo json_encode(["success" => false, "message" => "Missing data"]);
    exit;
}

// Upload file
$targetDir = "uploads/";
$fileName = time() . "_" . basename($file["name"]);
$targetFilePath = $targetDir . $fileName;

if (!move_uploaded_file($file["tmp_name"], $targetFilePath)) {
    echo json_encode(["success" => false, "message" => "File upload failed"]);
    exit;
}

// Update orders table (upload file only)
$update = $conn->prepare("UPDATE orders SET $field = ? WHERE order_id = ?");
$update->bind_param("si", $targetFilePath, $order_id);
$update->execute();

// Fetch full order to determine status
$stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

// Determine new status (kept your existing derivation)
if (!empty($order['brief_file'])) {
    if (!empty($order['d3_file']) ) {
        $new_status = "design phase";
    } else {
        $new_status = "waiting for 3d";
    }
}
if (!empty($order['prova_file'])) {
    $new_status = "prova uploaded";
}
if (!empty($order['production_file'])) {
    $new_status = "production files uploaded";
}
if (!empty($order['final_images'])) {
    $new_status = "images uploaded";
}
if (!empty($order['invoice_file'])) {
    $new_status = "invoice uploaded";
}

// Replace custom labels with the correct canonical ones (only change requested)
if ($field === "d3_file") {
    $new_status = "design phase";
} elseif ($field === "prova_file") {
    $new_status = "prova uploaded";
} elseif ($field === "production_file") {
    $new_status = "production files uploaded";
}

// Update order status
$updateStatus = $conn->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
$updateStatus->bind_param("si", $new_status, $order_id);
$updateStatus->execute();

// Insert into order_tracking
$comments = "Uploaded file for: $field";
$insertTrack = $conn->prepare("INSERT INTO order_tracking (order_id, status, assigned_to, comments, file_link, timestamp) VALUES (?, ?, ?, ?, ?, NOW())");
$insertTrack->bind_param("issss", $order_id, $new_status, $assigned_to, $comments, $targetFilePath);
$insertTrack->execute();

// Final response
echo json_encode([
    "success" => true,
    "message" => "File uploaded and status updated",
    "new_status" => $new_status,
    "file_path" => $targetFilePath
]);
?>
