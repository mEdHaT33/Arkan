<?php
// File: arkan-system/party_receipts.php
require_once __DIR__ . "/config.php";
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }

function bad($msg, $code = 400) {
  http_response_code($code);
  echo json_encode(["success" => false, "message" => $msg]);
  exit;
}

// Ensure table exists (no-op if already there)
$conn->query("
  CREATE TABLE IF NOT EXISTS party_receipts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    direction ENUM('in','out') NOT NULL,
    party_type ENUM('client','vendor') NOT NULL,
    party_id INT NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    method VARCHAR(50) DEFAULT NULL,
    reference VARCHAR(100) DEFAULT NULL,
    note VARCHAR(255) DEFAULT NULL,
    created_by VARCHAR(100) DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_party (party_type, party_id, created_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

/* ------- helpers for finance_txn mirroring ------- */
function get_or_create_category(mysqli $conn, string $name, string $kind): int {
  $sel = $conn->prepare("SELECT id FROM finance_category WHERE name = ? AND kind = ? LIMIT 1");
  $sel->bind_param("ss", $name, $kind);
  $sel->execute();
  $r = $sel->get_result()->fetch_assoc();
  if ($r) return (int)$r['id'];
  $ins = $conn->prepare("INSERT INTO finance_category (name, kind) VALUES (?, ?)");
  $ins->bind_param("ss", $name, $kind);
  $ins->execute();
  return $ins->insert_id;
}

function get_account_id(mysqli $conn, string $type): int {
  $sel = $conn->prepare("SELECT id FROM finance_account WHERE type = ? ORDER BY id ASC LIMIT 1");
  $sel->bind_param("s", $type);
  $sel->execute();
  $r = $sel->get_result()->fetch_assoc();
  if ($r) return (int)$r['id'];
  $name = ucfirst($type);
  $ins = $conn->prepare("INSERT INTO finance_account (name, type) VALUES (?, ?)");
  $ins->bind_param("ss", $name, $type);
  $ins->execute();
  return $ins->insert_id;
}
/* ----------------------------------------------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $payload = json_decode(file_get_contents("php://input"), true);
  if (!$payload) { $payload = $_POST; }

  $direction = strtolower(trim($payload['direction'] ?? ''));
  $partyType = strtolower(trim($payload['party_type'] ?? ''));
  $partyId   = intval($payload['party_id'] ?? 0);
  $amount    = floatval($payload['amount'] ?? 0);
  $method    = trim($payload['method'] ?? '');
  $reference = trim($payload['reference'] ?? '');
  $note      = trim($payload['note'] ?? '');
  $createdBy = trim($payload['created_by'] ?? 'finance');

  $account   = strtolower(trim($payload['account'] ?? 'bank'));
  $txnDate   = trim($payload['txn_date'] ?? '');
  if ($txnDate === '') $txnDate = date('Y-m-d');

  if (!in_array($direction, ['in','out'], true))        bad("direction must be 'in' or 'out'");
  if (!in_array($partyType, ['client','vendor'], true))  bad("party_type must be 'client' or 'vendor'");
  if (!in_array($account, ['bank','cash'], true))        bad("account must be 'bank' or 'cash'");
  if ($partyId <= 0)                                     bad("party_id is required");
  if ($amount < 0)                                      bad("amount must be >= 0");

  // Delta for balances
  $delta = 0.0;
  if ($partyType === 'client') { $delta = ($direction === 'in') ? -$amount : +$amount; }
  if ($partyType === 'vendor') { $delta = ($direction === 'out') ? -$amount : +$amount; }

  // Category mapping
  $catName = '';
  $catKind = '';
  if ($partyType === 'client' && $direction === 'in')  { $catName='Client Payment'; $catKind='income'; }
  if ($partyType === 'client' && $direction === 'out') { $catName='Client Refund';  $catKind='expense'; }
  if ($partyType === 'vendor' && $direction === 'out') { $catName='Vendor Payment'; $catKind='expense'; }
  if ($partyType === 'vendor' && $direction === 'in')  { $catName='Vendor Refund';  $catKind='income'; }

  $conn->begin_transaction();
  try {
    // Insert receipt
    $ins = $conn->prepare("INSERT INTO party_receipts (direction, party_type, party_id, amount, method, reference, note, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $ins->bind_param("ssisssss", $direction, $partyType, $partyId, $amount, $method, $reference, $note, $createdBy);
    $ins->execute();
    $newReceiptId = $ins->insert_id;

    $conn->commit();
    echo json_encode(["success" => true, "message" => "Receipt saved", "receipt_id" => $newReceiptId]);
  } catch (Throwable $e) {
    $conn->rollback();
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Transaction failed", "error" => $e->getMessage()]);
  }
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  $partyType = isset($_GET['party_type']) ? strtolower(trim($_GET['party_type'])) : null;
  $partyId   = isset($_GET['party_id'])   ? intval($_GET['party_id']) : null;
  $limit     = isset($_GET['limit'])      ? max(1, min(200, intval($_GET['limit']))) : 50;

  $where = [];
  $types = "";
  $params = [];

  if ($partyType && in_array($partyType, ['client','vendor'], true)) { $where[] = "pr.party_type = ?"; $types  .= "s"; $params[] = $partyType; }
  if ($partyId) { $where[] = "pr.party_id = ?"; $types  .= "i"; $params[] = $partyId; }

  $sql = "SELECT pr.*, cv.name AS party_name
          FROM party_receipts pr
          LEFT JOIN clients_vendors cv ON cv.id = pr.party_id
          " . (count($where) ? "WHERE ".implode(" AND ", $where) : "") . "
          ORDER BY pr.created_at DESC
          LIMIT ?";
  $types .= "i"; $params[] = $limit;
  $stmt = $conn->prepare($sql);
  $stmt->bind_param($types, ...$params);
  $stmt->execute();
  $res = $stmt->get_result();
  $rows = [];
  while ($r = $res->fetch_assoc()) { $rows[] = $r; }
  echo json_encode(["success" => true, "receipts" => $rows]);
  exit;
}

bad("Unsupported method", 405);
