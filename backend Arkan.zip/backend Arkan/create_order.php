<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

require_once "config.php";

$client_id = $_POST['client_id'] ?? null;
$created_by = $_POST['created_by'] ?? null;
$has_3d = $_POST['has_3d'] ?? "0";

if (!$client_id || !$created_by) {
    echo json_encode(["success" => false, "message" => "Missing required fields."]);
    exit;
}

function uploadFile($key, $targetDir = "uploads/") {
    if (!isset($_FILES[$key]) || $_FILES[$key]['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    $fileName = time() . "_" . basename($_FILES[$key]["name"]);
    $targetPath = $targetDir . $fileName;
    return move_uploaded_file($_FILES[$key]["tmp_name"], $targetPath) ? $targetPath : null;
}

$brief_file = uploadFile("brief_file");
$d3_file = uploadFile("d3_file");
$prova_file = uploadFile("prova_file");
$quotation_file = uploadFile("quotation_file");
$production_file = uploadFile("production_file");
$final_images = uploadFile("final_images");
$invoice_file = uploadFile("invoice_file");

// Auto status logic
//$status = "pending"; // default

if ($brief_file) {
    if ( $d3_file) {
        $status = "design phase";
    } else {
        $status = "waiting for 3d";
    }
}

if ($prova_file) {
    $status = "prova uploaded";
}

if ($quotation_file && $status === "design phase") {
    $status = "quotation uploaded";
}

if ($production_file) {
    $status = "production files uploaded";
}

if ($final_images) {
    $status = "images uploaded";
}

if ($invoice_file) {
    $status = "invoice uploaded";
}

$stmt = $conn->prepare("INSERT INTO orders (client_id, created_by, has_3d, brief_file, d3_file, prova_file , quotation_file, production_file, final_images, invoice_file, status, created_at) VALUES (?, ? , ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");

$stmt->bind_param("issssssssss", $client_id, $created_by, $has_3d, $brief_file, $d3_file, $prova_file , $quotation_file, $production_file, $final_images, $invoice_file, $status);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "status" => $status]);
} else {
    echo json_encode(["success" => false, "message" => "Database error: " . $stmt->error]);
}
?>
