<?php
require_once "config.php";
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// Receive POST data
$data = json_decode(file_get_contents("php://input"), true);

$vendor_id = $data["vendor_id"];
$date = $data["date"];
$items = $data["items"]; // array of items

// Insert into purchase_receipts table
$stmt = $conn->prepare("INSERT INTO purchase_receipts (vendor_id, date) VALUES (?, ?)");
$stmt->bind_param("is", $vendor_id, $date);

if ($stmt->execute()) {
    $receipt_id = $stmt->insert_id;

    // Insert each item into purchase_items
    foreach ($items as $item) {
        $stmt_item = $conn->prepare("INSERT INTO purchase_items (receipt_id, item_name, item_code, description, price, qty, discount, tax) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt_item->bind_param(
            "isssddds",
            $receipt_id,
            $item["item_name"],
            $item["item_code"],
            $item["description"],
            $item["price"],
            $item["qty"],
            $item["discount"],
            $item["tax"]
        );
        $stmt_item->execute();

        // Update warehouse
        $check = $conn->prepare("SELECT id FROM warehouse WHERE item_code = ?");
        $check->bind_param("s", $item["item_code"]);
        $check->execute();
        $res = $check->get_result();

        if ($res->num_rows > 0) {
            // Update quantity
            $row = $res->fetch_assoc();
            $update = $conn->prepare("UPDATE warehouse SET qty = qty + ?, price = ? WHERE id = ?");
            $update->bind_param("dii", $item["qty"], $item["price"], $row["id"]);
            $update->execute();
        } else {
            // Insert new item into warehouse
            $insert = $conn->prepare("INSERT INTO warehouse (item_name, item_code, description, qty, price) VALUES (?, ?, ?, ?, ?)");
            $insert->bind_param("sssdd", $item["item_name"], $item["item_code"], $item["description"], $item["qty"], $item["price"]);
            $insert->execute();
        }
    }

    echo json_encode(["success" => true, "receipt_id" => $receipt_id]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to create receipt."]);
}
?>
