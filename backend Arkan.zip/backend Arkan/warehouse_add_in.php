<?php
require_once "config.php";
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

// Ensure the Item_Stock column exists (stores stock before the IN transaction)
$conn->query("ALTER TABLE warehouse_in ADD COLUMN IF NOT EXISTS Item_Stock DECIMAL(12,4) NULL AFTER qty");

$data = json_decode(file_get_contents("php://input"), true);
$item_id     = isset($data["item_id"]) ? intval($data["item_id"]) : 0;
$qty         = isset($data["qty"]) ? floatval($data["qty"]) : 0;
$unit_cost   = isset($data["unit_cost"]) ? (strlen($data["unit_cost"]) ? floatval($data["unit_cost"]) : null) : null;
$supplier_id = isset($data["supplier_id"]) ? (strlen($data["supplier_id"]) ? intval($data["supplier_id"]) : null) : null;
$po_number   = isset($data["po_number"]) ? trim($data["po_number"]) : null;
$note        = isset($data["note"]) ? trim($data["note"]) : null;
$received_by = isset($data["received_by"]) ? trim($data["received_by"]) : null;
// Optional receipt date (YYYY-MM-DD)
$receipt_date = (isset($data["receipt_date"]) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $data["receipt_date"])) ? trim($data["receipt_date"]) : null;
// if ($receipt_date !== null && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $receipt_date)) {
//   // invalid format -> ignore to avoid DB issues
//   $receipt_date = null;
// }

if ($item_id <= 0 || $qty <= 0) {
  echo json_encode(["success"=>false, "message"=>"Invalid item or qty"]);
  exit;
}

// Read current stock before adding
$curStock = 0.0;
$q = $conn->prepare("SELECT quantity FROM warehouse_item WHERE item_id = ? LIMIT 1");
$q->bind_param("i", $item_id);
$q->execute();
$rr = $q->get_result()->fetch_assoc();
if ($rr) { $curStock = floatval($rr['quantity']) + $qty; }

// Get today's date for the date column
$today_date = date('Y-m-d H:i:s');

if ($receipt_date !== null) {
  $stmt = $conn->prepare("INSERT INTO warehouse_in (item_id, qty, Item_Stock, unit_cost, supplier_id, po_number, note, received_by, received_at, date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
  $stmt->bind_param("idddisssss", $item_id, $qty, $curStock, $unit_cost, $supplier_id, $po_number, $note, $received_by, $receipt_date, $today_date);
} else {
  $stmt = $conn->prepare("INSERT INTO warehouse_in (item_id, qty, Item_Stock, unit_cost, supplier_id, po_number, note, received_by, date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
  $stmt->bind_param("idddissss", $item_id, $qty, $curStock, $unit_cost, $supplier_id, $po_number, $note, $received_by, $today_date);
}

if ($stmt->execute()) {
  // triggers will update warehouse_item.quantity
  echo json_encode(["success"=>true, "id"=>$conn->insert_id]);
} else {
  echo json_encode(["success"=>false, "message"=>"DB error: ".$stmt->error]);
}
