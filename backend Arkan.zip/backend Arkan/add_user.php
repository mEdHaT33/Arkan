<?php
session_start();
header("Content-Type: application/json");

// Only allow admin
if (!isset($_SESSION["loggedin"]) || $_SESSION["role"] !== "admin") {
    http_response_code(403);
    echo json_encode(["error" => "Access denied"]);
    exit;
}

include("config.php");

// Read JSON input from React
$data = json_decode(file_get_contents("php://input"), true);

$username = trim($data["username"]);
$password = trim($data["password"]);
$role     = trim($data["role"]);
$email    = trim($data["email"]);
$phone    = trim($data["phone"]);

// Basic validation
if (!$username || !$password || !$role) {
    http_response_code(400);
    echo json_encode(["error" => "Missing required fields"]);
    exit;
}

// Insert user into DB (password not hashed as requested)
$stmt = $conn->prepare("INSERT INTO users (username, password, role, email, phone) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $username, $password, $role, $email, $phone);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "User added"]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Failed to insert user"]);
}
?>
