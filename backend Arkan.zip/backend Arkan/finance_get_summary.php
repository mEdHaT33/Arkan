<?php
require_once "config.php";
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }
function getSingle($conn, $sql, $types = "", $params = []) {
  $stmt = $conn->prepare($sql);
  if (!$stmt) { return [0, "Prepare failed: ".$conn->error]; }
  if ($types && $params) { $stmt->bind_param($types, ...$params); }
  if (!$stmt->execute()) { return [0, "Execute failed: ".$stmt->error]; }
  $res = $stmt->get_result();
  if (!$res) { return [0, "No result set"]; }
  $row = $res->fetch_row();
  return [$row ? (float)$row[0] : 0.0, null];
}

$diag = []; // collect warnings/messages

// Resolve Bank/Cash IDs
list($bankId,) = getSingle($conn, "SELECT id FROM finance_account WHERE name='Bank' LIMIT 1");
list($cashId,) = getSingle($conn, "SELECT id FROM finance_account WHERE name='Cash' LIMIT 1");
if (!$bankId) $diag[] = "Bank account missing in finance_account.";
if (!$cashId) $diag[] = "Cash account missing in finance_account.";

// Balances
list($bankIn,$e)  = getSingle($conn, "SELECT COALESCE(SUM(amount),0) FROM finance_txn WHERE account_id=? AND direction='in'","i",[$bankId]);
if ($e) $diag[] = "Bank IN error: $e";
list($bankOut,$e) = getSingle($conn, "SELECT COALESCE(SUM(amount),0) FROM finance_txn WHERE account_id=? AND direction='out'","i",[$bankId]);
if ($e) $diag[] = "Bank OUT error: $e";

list($cashIn,$e)  = getSingle($conn, "SELECT COALESCE(SUM(amount),0) FROM finance_txn WHERE account_id=? AND direction='in'","i",[$cashId]);
if ($e) $diag[] = "Cash IN error: $e";
list($cashOut,$e) = getSingle($conn, "SELECT COALESCE(SUM(amount),0) FROM finance_txn WHERE account_id=? AND direction='out'","i",[$cashId]);
if ($e) $diag[] = "Cash OUT error: $e";

$bankBalance = $bankIn - $bankOut;
$cashBalance = $cashIn - $cashOut;

// Totals
list($totalIn,$e)  = getSingle($conn, "SELECT COALESCE(SUM(amount),0) FROM finance_txn WHERE direction='in'");
if ($e) $diag[] = "Total IN error: $e";
list($totalOut,$e) = getSingle($conn, "SELECT COALESCE(SUM(amount),0) FROM finance_txn WHERE direction='out'");
if ($e) $diag[] = "Total OUT error: $e";

// Last 30 days
list($last30In,$e)  = getSingle($conn, "SELECT COALESCE(SUM(amount),0) FROM finance_txn WHERE direction='in' AND txn_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)");
if ($e) $diag[] = "30d IN error: $e";
list($last30Out,$e) = getSingle($conn, "SELECT COALESCE(SUM(amount),0) FROM finance_txn WHERE direction='out' AND txn_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)");
if ($e) $diag[] = "30d OUT error: $e";

// Receipts (optional tables; ignore if missing)
list($receiptIn,$e)  = getSingle($conn, "SELECT COALESCE(SUM(amount),0) FROM fin_receipt_in");
if ($e) $diag[] = "Receipts IN error (table may not exist): $e";
list($receiptOut,$e) = getSingle($conn, "SELECT COALESCE(SUM(amount),0) FROM fin_receipt_out");
if ($e) $diag[] = "Receipts OUT error (table may not exist): $e";

// Warehouse value — check if view exists
$warehouseValue = 0.0;
$viewExists = false;
$dbname = $conn->query("SELECT DATABASE()")->fetch_row()[0];
$check = $conn->prepare("
  SELECT TABLE_NAME FROM INFORMATION_SCHEMA.VIEWS
  WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'v_warehouse_value' LIMIT 1
");
$check->bind_param("s", $dbname);
$check->execute();
$r = $check->get_result();
if ($r && $r->num_rows > 0) {
  $viewExists = true;
}
if ($viewExists) {
  list($warehouseValue,$e) = getSingle($conn, "SELECT COALESCE(total_value,0) FROM v_warehouse_value");
  if ($e) $diag[] = "Warehouse view error: $e";
} else {
  $diag[] = "View v_warehouse_value not found. Using 0 as fallback.";
}

// Categories
$categories = [];
$catRes = $conn->query("SELECT id, name, kind FROM finance_category ORDER BY name");
if ($catRes) {
  while ($row = $catRes->fetch_assoc()) { $categories[] = $row; }
} else {
  $diag[] = "Category fetch error: ".$conn->error;
}

echo json_encode([
  "success" => true,
  "balances" => ["bank" => (float)$bankBalance, "cash" => (float)$cashBalance],
  "totals"   => ["in_all_time" => (float)$totalIn, "out_all_time" => (float)$totalOut, "in_30d" => (float)$last30In, "out_30d" => (float)$last30Out],
  "receipts" => ["in" => (float)$receiptIn, "out" => (float)$receiptOut],
  "warehouse"=> ["total_value" => (float)$warehouseValue],
  "categories" => $categories,
  "diagnostics" => $diag
]);
