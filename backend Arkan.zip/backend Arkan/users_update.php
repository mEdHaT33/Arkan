<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once "config.php";

$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

$id       = $data['id']       ?? null;
$username = $data['username'] ?? null;
$password = $data['password'] ?? null; // optional; if empty => keep same
$role     = $data['role']     ?? null;
$email    = $data['email']    ?? null;
$phone    = $data['phone']    ?? null;

if (!$id || !$username || !$role) {
  echo json_encode(["success" => false, "message" => "Missing required fields."]);
  exit;
}

try {
  if ($password !== null && $password !== "") {
    // Update all fields including password
    $stmt = $conn->prepare("UPDATE users SET username=?, password=?, role=?, email=?, phone=? WHERE id=?");
    $stmt->bind_param("sssssi", $username, $password, $role, $email, $phone, $id);
  } else {
    // Keep current password
    $stmt = $conn->prepare("UPDATE users SET username=?, role=?, email=?, phone=? WHERE id=?");
    $stmt->bind_param("ssssi", $username, $role, $email, $phone, $id);
  }
  if (!$stmt->execute()) {
    echo json_encode(["success" => false, "message" => "Database error: ".$stmt->error]); exit;
  }
  echo json_encode(["success" => true]);
} catch (Throwable $e) {
  echo json_encode(["success" => false, "message" => "Server error: ".$e->getMessage()]);
}
