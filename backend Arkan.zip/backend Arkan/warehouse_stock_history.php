<?php
require_once "config.php";
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

$item_id = isset($_GET["item_id"]) ? intval($_GET["item_id"]) : 0;
$from    = isset($_GET["from"]) ? trim($_GET["from"]) : null;   // YYYY-MM-DD
$to      = isset($_GET["to"])   ? trim($_GET["to"])   : null;   // YYYY-MM-DD
$limit   = isset($_GET["limit"]) ? max(1, min(1000, intval($_GET["limit"]))) : 300;

if ($item_id <= 0) {
  echo json_encode(["success" => false, "message" => "item_id is required"]);
  exit;
}

// Ensure ledger table exists (no-op if present)
$conn->query("
  CREATE TABLE IF NOT EXISTS warehouse_stock_ledger (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT NOT NULL,
    txn_type ENUM('in','out') NOT NULL,
    txn_id INT NOT NULL,
    txn_date DATE NOT NULL,
    qty_delta DECIMAL(12,4) NOT NULL,
    balance_after DECIMAL(12,4) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_txn (txn_type, txn_id),
    KEY idx_item_date (item_id, txn_date, id),
    CONSTRAINT fk_ledger_item FOREIGN KEY (item_id) REFERENCES warehouse_item(item_id)
      ON UPDATE CASCADE ON DELETE RESTRICT
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

$sql = "SELECT l.id, l.item_id, l.txn_type, l.txn_id, l.txn_date, l.qty_delta, l.balance_after, l.created_at,
               i.item_code, i.item_name
        FROM warehouse_stock_ledger l
        JOIN warehouse_item i ON i.item_id = l.item_id
        WHERE l.item_id = ?";
$params = [$item_id];
$types  = "i";

if ($from) { $sql .= " AND l.txn_date >= ?"; $types .= "s"; $params[] = $from; }
if ($to)   { $sql .= " AND l.txn_date <= ?"; $types .= "s"; $params[] = $to; }

$sql .= " ORDER BY l.txn_date ASC, l.id ASC LIMIT ?";
$types .= "i"; $params[] = $limit;

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();

$rows = [];
while ($row = $res->fetch_assoc()) { $rows[] = $row; }

echo json_encode(["success" => true, "history" => $rows]);
