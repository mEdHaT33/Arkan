<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once "config.php";

$raw  = file_get_contents("php://input");
$data = json_decode($raw, true);

$id       = $data['id']       ?? null;
$name     = $data['name']     ?? null;
$type     = $data['type']     ?? null;     // 'client' | 'vendor'
$address  = $data['address']  ?? null;
$tax_id   = $data['tax_id']   ?? null;
$phone    = $data['phone']    ?? null;
$email    = $data['email']    ?? null;
$balance  = $data['balance']  ?? null;     // optional; if null/"" => keep same

if (!$id || !$name || !$type) {
  echo json_encode(["success" => false, "message" => "Missing required fields."]);
  exit;
}

try {
  if ($balance !== null && $balance !== "") {
    if (!is_numeric($balance)) {
      echo json_encode(["success"=>false, "message"=>"Invalid balance"]); exit;
    }
    // Update all fields including balance
    $stmt = $conn->prepare("
      UPDATE clients_vendors
      SET name=?, address=?, tax_id=?, phone=?, email=?, type=?, balance=?
      WHERE id=?
    ");
    $bal = (float)$balance;
    $stmt->bind_param("ssssssdi", $name, $address, $tax_id, $phone, $email, $type, $bal, $id);
  } else {
    // Keep current balance
    $stmt = $conn->prepare("
      UPDATE clients_vendors
      SET name=?, address=?, tax_id=?, phone=?, email=?, type=?
      WHERE id=?
    ");
    $stmt->bind_param("ssssssi", $name, $address, $tax_id, $phone, $email, $type, $id);
  }

  if (!$stmt->execute()) {
    echo json_encode(["success" => false, "message" => "Database error: ".$stmt->error]); exit;
  }

  echo json_encode(["success" => true]);
} catch (Throwable $e) {
  echo json_encode(["success" => false, "message" => "Server error: ".$e->getMessage()]);
}
