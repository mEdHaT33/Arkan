<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}
include("../config.php");

// Handle Add User
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add'])) {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $stmt = $conn->prepare("INSERT INTO users (username, password, role, email, phone) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $username, $password, $role, $email, $phone);
    $stmt->execute();
}

// Handle Delete
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM users WHERE id=$id");
}

// Get all users
$users = $conn->query("SELECT * FROM users");
?>

<h2>👤 User Management</h2>
<a href="../dashboard.php">← Back to Dashboard</a>

<h3>Add New User</h3>
<form method="post">
    <input name="username" placeholder="Username" required>
    <input name="password" placeholder="Password" required>
    <select name="role">
        <option value="admin">admin</option>
        <option value="account manager">account manager</option>
        <option value="designer manager">designer manager</option>
        <option value="designer">designer</option>
        <option value="finance">finance</option>
    </select>
    <input name="email" placeholder="Email">
    <input name="phone" placeholder="Phone">
    <button name="add" type="submit">➕ Add User</button>
</form>

<h3>All Users</h3>
<table border="1" cellpadding="6">
    <tr>
        <th>ID</th><th>Username</th><th>Role</th><th>Email</th><th>Phone</th><th>Actions</th>
    </tr>
    <?php while ($row = $users->fetch_assoc()): ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['username'] ?></td>
        <td><?= $row['role'] ?></td>
        <td><?= $row['email'] ?></td>
        <td><?= $row['phone'] ?></td>
        <td><a href="?delete=<?= $row['id'] ?>" onclick="return confirm('Delete user?')">🗑️ Delete</a></td>
    </tr>
    <?php endwhile; ?>
</table>
