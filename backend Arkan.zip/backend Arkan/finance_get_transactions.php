<?php
require_once "config.php";
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }

try {
  // Read and sanitize filters
  $from        = isset($_GET["from"]) ? trim($_GET["from"]) : "";
  $to          = isset($_GET["to"]) ? trim($_GET["to"]) : "";
  $category_id = isset($_GET["category_id"]) && $_GET["category_id"] !== "" ? (int)$_GET["category_id"] : null;
  $account     = isset($_GET["account"]) ? trim($_GET["account"]) : "";
  $direction   = isset($_GET["direction"]) ? trim($_GET["direction"]) : "";
  $kind        = isset($_GET["kind"]) ? trim($_GET["kind"]) : "";

  // Validate YYYY-MM-DD dates (ignore if invalid)
  $dateOk = function($s) {
    return preg_match('/^\d{4}-\d{2}-\d{2}$/', $s) === 1;
  };
  $fromOk = $from && $dateOk($from);
  $toOk   = $to   && $dateOk($to);

  // Validate enumerations
  $accountOk   = in_array($account, ["bank","cash",""], true);
  $directionOk = in_array($direction, ["in","out",""], true);
  $kindOk      = in_array($kind, ["income","expense",""], true);
  if (!$accountOk)   $account = "";     // ignore bad value
  if (!$directionOk) $direction = "";   // ignore bad value
  if (!$kindOk)      $kind = "";        // ignore bad value

  $sql = "SELECT
            t.id,
            t.txn_date,
            c.name AS category,
            c.kind,
            a.name AS account,
            t.direction,
            t.amount,
            t.note,
            t.created_by,
            t.created_at,
            /* NEW: running balances after this transaction */
            t.cash_balance_after,
            t.bank_balance_after
          FROM finance_txn t
          JOIN finance_category c ON c.id = t.category_id
          JOIN finance_account a  ON a.id = t.account_id
          WHERE 1=1";
  $types = "";
  $params = [];

  if ($fromOk) { $sql .= " AND t.txn_date >= ?"; $types.="s"; $params[]=$from; }
  if ($toOk)   { $sql .= " AND t.txn_date <= ?"; $types.="s"; $params[]=$to; }
  if (!is_null($category_id)) { $sql .= " AND t.category_id = ?"; $types.="i"; $params[]=$category_id; }
  if ($account !== "") { $sql .= " AND a.type = ?"; $types.="s"; $params[]=$account; }
  if ($direction !== "") { $sql .= " AND t.direction = ?"; $types.="s"; $params[]=$direction; }
  if ($kind !== "") { $sql .= " AND c.kind = ?"; $types.="s"; $params[]=$kind; }

  $sql .= " ORDER BY t.txn_date DESC, t.id DESC";

  $stmt = $conn->prepare($sql);
  if (!$stmt) {
    throw new Exception("Prepare failed: ".$conn->error);
  }
  if ($types !== "") {
    if (!$stmt->bind_param($types, ...$params)) {
      throw new Exception("Bind failed: ".$stmt->error);
    }
  }
  if (!$stmt->execute()) {
    throw new Exception("Execute failed: ".$stmt->error);
  }

  $res = $stmt->get_result();
  $out = [];
  while ($row = $res->fetch_assoc()) { $out[] = $row; }

  echo json_encode(["success"=>true, "transactions"=>$out]);

} catch (Exception $e) {
  http_response_code(400);
  echo json_encode([
    "success"=>false,
    "message"=>"finance_get_transactions error",
    "error"=>$e->getMessage()
  ]);
}
