<?php
session_start();

// Prevent access if not logged in
if (!isset($_SESSION["loggedin"])) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION["username"];
$role = $_SESSION["role"];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Arkan System</title>
</head>
<body>
    <h2>✅ Welcome to Arkan System Dashboard</h2>
    <p>Hello, <strong><?= $username ?></strong> (Role: <strong><?= $role ?></strong>)</p>

    <h3>🔗 Available Actions</h3>
    <ul>
        <li><a href="manage_users.php">Manage Users</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</body>
</html>
