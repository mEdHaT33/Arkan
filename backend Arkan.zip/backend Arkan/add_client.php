<?php
require_once "config.php";

// Allow CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Read JSON input
$data = json_decode(file_get_contents("php://input"), true);

if (!$data || !isset($data['name']) || !isset($data['type'])) {
    echo json_encode(["success" => false, "message" => "Missing required fields"]);
    exit;
}

$name = $data["name"];
$address = $data["address"] ?? "";
$tax_id = $data["tax_id"] ?? "";
$phone = $data["phone"] ?? "";
$email = $data["email"] ?? "";
$balance = $data["balance"] ?? "0";
$type = $data["type"];

$stmt = $conn->prepare("INSERT INTO clients_vendors (name, address, tax_id, phone, email, balance, type) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssss", $name, $address, $tax_id, $phone, $email, $balance, $type);

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "message" => "DB Insert Failed"]);
}
?>
