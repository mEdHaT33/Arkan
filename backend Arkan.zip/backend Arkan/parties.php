<?php
// File: arkan-system/parties.php
require_once __DIR__ . "/config.php";
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }

$type = isset($_GET['type']) ? strtolower(trim($_GET['type'])) : null; // client|vendor|null

try {
    if ($type === 'client' || $type === 'vendor') {
        $sql = "SELECT id, name, type, balance, email, phone
                FROM clients_vendors
                WHERE type IN ('client','vendor') AND type = ?
                ORDER BY name ASC, id ASC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $type);
    } else {
        $sql = "SELECT id, name, type, balance, email, phone
                FROM clients_vendors
                WHERE type IN ('client','vendor')
                ORDER BY name ASC, id ASC";
        $stmt = $conn->prepare($sql);
    }

    $stmt->execute();
    $res = $stmt->get_result();
    $rows = [];
    while ($r = $res->fetch_assoc()) { $rows[] = $r; }

    echo json_encode(["success" => true, "parties" => $rows]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Server error", "error" => $e->getMessage()]);
}
