<?php
require_once "config.php";
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);
$order_id = $data['order_id'] ?? null;
$username = $data['designer_username'] ?? null;

if (!$order_id || !$username) {
  echo json_encode(["success" => false, "message" => "Missing data"]);
  exit;
}

$stmt = $conn->prepare("UPDATE orders SET designer_assigned_to = ? WHERE order_id = ?");
$stmt->bind_param("si", $username, $order_id);
$stmt->execute();

echo json_encode(["success" => true]);
?>
