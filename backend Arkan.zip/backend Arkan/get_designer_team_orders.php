<?php
require_once "config.php";
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$username = $_GET['username'] ?? '';
if (!$username) { echo json_encode(["success"=>false,"message"=>"Missing username"]); exit; }

// The four statuses you want
$allowed_statuses = ["quotation uploaded", "waiting for 3d", "design phase", "approved"];

$placeholders = implode(',', array_fill(0, count($allowed_statuses), '?'));
$sql = "SELECT * FROM orders WHERE designer_assigned_to = ? AND status IN ($placeholders)";
$stmt = $conn->prepare($sql);

$params = array_merge([$username], $allowed_statuses);
$types  = str_repeat('s', count($params));
$stmt->bind_param($types, ...$params);

$stmt->execute();
$result = $stmt->get_result();

$orders = [];
while ($row = $result->fetch_assoc()) { $orders[] = $row; }

echo json_encode(["success"=>true, "orders"=>$orders]);
