<?php
/**
 * send_mail.php
 * Location: /public_html/arkanaltafawuq.com/arkan-system/send_mail.php
 * Usage (GET quick test): https://yourdomain.com/arkan-system/send_mail.php
 * Usage (POST JSON): to, subject, html, text (optional)
 */

// CORS for frontend calls (dev/prod)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json; charset=utf-8");
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

error_reporting(E_ALL);
ini_set('display_errors', 1);

// --- CONFIG: set your mailbox password and default admin recipient ---
$SMTP_HOST = 'mail.arkanaltafawuq.com';
$SMTP_PORT = 465;             // SSL
$SMTP_SECURE = 'ssl';         // matches your cPanel screen
$SMTP_USER = 'no-reply@arkanaltafawuq.com';
$SMTP_PASS = 'Arkan123!@#';   // <-- PUT YOUR PASSWORD

$MAIL_FROM      = 'no-reply@arkanaltafawuq.com';
$MAIL_FROM_NAME = 'Arkan System';
$MAIL_TO_ADMIN  = 'ahmedmedhat@binrashideg.com';  

// --- Locate PHPMailer (supports either arkan-system/phpmailer or ../phpmailer) ---
$path1 = __DIR__ . '/phpmailer/src/PHPMailer.php';
$path2 = __DIR__ . '/../phpmailer/src/PHPMailer.php';
if (file_exists($path1)) {
  require_once __DIR__ . '/phpmailer/src/PHPMailer.php';
  require_once __DIR__ . '/phpmailer/src/SMTP.php';
  require_once __DIR__ . '/phpmailer/src/Exception.php';
} elseif (file_exists($path2)) {
  require_once __DIR__ . '/../phpmailer/src/PHPMailer.php';
  require_once __DIR__ . '/../phpmailer/src/SMTP.php';
  require_once __DIR__ . '/../phpmailer/src/Exception.php';
} else {
  http_response_code(500);
  exit('PHPMailer not found. Place "phpmailer/src" in arkan-system/ or its parent.');
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// --- Read inputs (supports GET for quick test, or JSON/POST) ---
$raw = file_get_contents('php://input');
$payload = json_decode($raw, true);
if (!is_array($payload)) $payload = $_POST;

$to      = $payload['to']      ?? $MAIL_TO_ADMIN;
$subject = $payload['subject'] ?? 'Order Created Email from Arkan System';
$html    = $payload['html']    ?? '<p> This mail shows that there is order cereated by [....].</p>';
$text    = $payload['text']    ?? strip_tags($html);
$replyTo = $payload['replyTo'] ?? null; // e.g. "client@example.com"

// Optional debug via query: ?debug=1
$debug = isset($_GET['debug']) ? (int)$_GET['debug'] : 0;

$mail = new PHPMailer(true);
try {
  if ($debug) {
    $mail->SMTPDebug = 2;       // show SMTP transcript
    $mail->Debugoutput = 'html';
  }

  // SMTP
  $mail->isSMTP();
  $mail->Host       = $SMTP_HOST;
  $mail->SMTPAuth   = true;
  $mail->Username   = $SMTP_USER;
  $mail->Password   = $SMTP_PASS;
  $mail->SMTPSecure = $SMTP_SECURE;  // 'ssl'
  $mail->Port       = $SMTP_PORT;    // 465

  // Sometimes shared hosts need relaxed SSL verification
  $mail->SMTPOptions = [
    'ssl' => [
      'verify_peer'       => false,
      'verify_peer_name'  => false,
      'allow_self_signed' => true,
    ]
  ];

  // Addresses
  $mail->setFrom($MAIL_FROM, $MAIL_FROM_NAME);
  // support comma-separated list
  foreach (is_array($to) ? $to : explode(',', $to) as $addr) {
    $addr = trim($addr);
    if ($addr !== '') $mail->addAddress($addr);
  }
  if ($replyTo) $mail->addReplyTo($replyTo);

  // Content
  $mail->isHTML(true);
  $mail->Subject = $subject;
  $mail->Body    = $html;
  $mail->AltBody = $text;

  $mail->send();

  // JSON success
  header('Content-Type: application/json');
  echo json_encode(['success' => true, 'message' => 'Email sent']);
} catch (Exception $e) {
  // JSON failure with PHPMailer’s message
  header('Content-Type: application/json', true, 500);
  echo json_encode(['success' => false, 'error' => $mail->ErrorInfo]);
}
