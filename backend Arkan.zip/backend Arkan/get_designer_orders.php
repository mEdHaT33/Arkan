<?php
require_once "config.php";
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// Sanitize and normalize status
$status = isset($_GET['status']) ? trim(strtolower($_GET['status'])) : '';

if (empty($status)) {
    echo json_encode(["success" => false, "message" => "Missing status"]);
    exit;
}

// Debug (optional): log incoming status
// file_put_contents("debug_status_log.txt", $status . PHP_EOL, FILE_APPEND);

// Use LOWER(status) to allow case-insensitive match
$stmt = $conn->prepare("SELECT * FROM orders WHERE LOWER(status) = ?");
$stmt->bind_param("s", $status);
$stmt->execute();
$result = $stmt->get_result();

$orders = [];
while ($row = $result->fetch_assoc()) {
    $orders[] = $row;
}

echo json_encode([
    "success" => true,
    "orders" => $orders
]);
?>
